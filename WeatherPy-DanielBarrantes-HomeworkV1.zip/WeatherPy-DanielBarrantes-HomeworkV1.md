
# WeatherPy
----

#### Note
* Instructions have been included for each segment. You do not have to follow them exactly, but they are included to help you think through the steps.


```python
# Dependencies and Setup
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import requests
from requests.exceptions import HTTPError
import openweathermapy.core as owm
import time

# Import API key
from config2 import api_key

# Incorporated citipy to determine city based on latitude and longitude
from citipy import citipy

# Output File (CSV)
output_data_file = "output_data/cities.csv"

# Range of latitudes and longitudes
lat_range = (-90, 90)
lng_range = (-180, 180)

api_key
```




    '9586ef608bbf0838f9b387e9d8d4b1da'



## Generate Cities List


```python
# List for holding lat_lngs and cities ok
lat_lngs = []
cities = []

# Create a set of random lat and lng combinations
lats = np.random.uniform(low=-90.000, high=90.000, size=1500)
lngs = np.random.uniform(low=-180.000, high=180.000, size=1500)
lat_lngs = zip(lats, lngs)

# Identify nearest city for each lat, lng combination
for lat_lng in lat_lngs:
    city = citipy.nearest_city(lat_lng[0], lat_lng[1]).city_name
    
    # If the city is unique, then add it to a our cities list
    if city not in cities:
        cities.append(city)

# Print the city count to confirm sufficient count
len(cities)
cities
```




    ['husavik',
     'arraial do cabo',
     'cavalcante',
     'punta arenas',
     'alofi',
     'bluff',
     'busselton',
     'qaanaaq',
     'rikitea',
     'mataura',
     'udachnyy',
     'east london',
     'albany',
     'ushuaia',
     'magole',
     'hermanus',
     'cape town',
     'sao joao da barra',
     'hobart',
     'tiksi',
     'souillac',
     'severo-kurilsk',
     'butaritari',
     'jamestown',
     'chokurdakh',
     'oltu',
     'neiafu',
     'sur',
     'bethel',
     'sabha',
     'avarua',
     'khatanga',
     'mahebourg',
     'muros',
     'umzimvubu',
     'new norfolk',
     'sabancuy',
     'puerto ayora',
     'genhe',
     'georgetown',
     'pevek',
     'barrow',
     'balaguer',
     'yinchuan',
     'villamontes',
     'bulnes',
     'hilo',
     'kamenskoye',
     'saldanha',
     'vostok',
     'dickinson',
     'babra',
     'zhangjiakou',
     'port alfred',
     'najran',
     'nikolskoye',
     'turukhansk',
     'sitka',
     'saleaula',
     'znamenskoye',
     'asadabad',
     'bredasdorp',
     'sainte-maxime',
     'illoqqortoormiut',
     'atuona',
     'vaini',
     'zangakatun',
     'thompson',
     'pichayevo',
     'tuktoyaktuk',
     'mullaitivu',
     'gat',
     'samarai',
     'vieques',
     'guangyuan',
     'kautokeino',
     'tyler',
     'olivet',
     'chuy',
     'shiyan',
     'sinnamary',
     'upernavik',
     'amderma',
     'iranshahr',
     'launceston',
     'hohhot',
     'doha',
     'marsh harbour',
     'venado tuerto',
     'baculin',
     'kenai',
     'carnarvon',
     'samusu',
     'beira',
     'lompoc',
     'lagoa',
     'nizhniy baskunchak',
     'kyzyl-suu',
     'berlevag',
     'ballina',
     'barentsburg',
     'toftir',
     'labuhan',
     'kendari',
     'boyolangu',
     'srednekolymsk',
     'constitucion',
     'yellowknife',
     'sahrak',
     'paamiut',
     'berbera',
     'norman wells',
     'ekibastuz',
     'saint-joseph',
     'itarema',
     'nanortalik',
     'inhambane',
     'saint george',
     'tubuala',
     'petauke',
     'belushya guba',
     'kushima',
     'mackay',
     'acajutla',
     'tsihombe',
     'mazagao',
     'tabiauea',
     'kilindoni',
     'yumen',
     'geraldton',
     'miri',
     'sloboda',
     'redlands',
     'duluth',
     'coahuayana',
     'kushiro',
     'luderitz',
     'saint-philippe',
     'atambua',
     'goderich',
     'ilulissat',
     'teguise',
     'santa rosa',
     'karratha',
     'portland',
     'salalah',
     'ostroda',
     'san felipe',
     'klichka',
     'bambous virieux',
     'manakara',
     'ust-koksa',
     'santa isabel',
     'owando',
     'tetouan',
     'leningradskiy',
     'taolanaro',
     'ribeira grande',
     'pangnirtung',
     'haines junction',
     'okha',
     'ancud',
     'firminy',
     'vila velha',
     'zorritos',
     'jalpan',
     'kreuztal',
     'dingle',
     'longyearbyen',
     'iqaluit',
     'hovd',
     'lazaro cardenas',
     'auki',
     'coihaique',
     'mys shmidta',
     'kihei',
     'adrar',
     'keti bandar',
     'acapulco',
     'laguilayan',
     'berberati',
     'port elizabeth',
     'namatanai',
     'vila franca do campo',
     'jalu',
     'marcona',
     'northam',
     'mayumba',
     'tasiilaq',
     'hindoria',
     'namibe',
     'esperance',
     'saint-louis',
     'narsaq',
     'chipinge',
     'saskylakh',
     'havoysund',
     'yiyang',
     'playas',
     'statesboro',
     'kruisfontein',
     'honiara',
     'vanino',
     'takoradi',
     'lere',
     'kodiak',
     'dikson',
     'vila',
     'sobolevo',
     'zhigansk',
     'monroe',
     'galiwinku',
     'nishihara',
     'puerto leguizamo',
     'kapaa',
     'sosnovo-ozerskoye',
     'cabo san lucas',
     'swellendam',
     'turka',
     'baykit',
     'provideniya',
     'ipil',
     'mbandaka',
     'ende',
     'san patricio',
     'ixtapa',
     'agapovka',
     'lasa',
     'savannah bight',
     'dunedin',
     'pietarsaari',
     'trinidad',
     'hithadhoo',
     'tumannyy',
     'ylivieska',
     'mount isa',
     'yar-sale',
     'havelock',
     'tobol',
     'monrovia',
     'caravelas',
     'sao filipe',
     'sungairaya',
     'lebu',
     'huangpi',
     'kunigal',
     'cap malheureux',
     'bure',
     'nizhneyansk',
     'touros',
     'lichinga',
     'abakaliki',
     'svetlogorsk',
     'toguchin',
     'guerrero negro',
     'tuatapere',
     'cabra',
     'torbay',
     'cherskiy',
     'jalalpur jattan',
     'ahipara',
     'airai',
     'chapais',
     'vanavara',
     'salinas',
     'viligili',
     'shitkino',
     'dauphin',
     'cayenne',
     'mashhad',
     'lolua',
     'ponta do sol',
     'kushmurun',
     'gallup',
     'mar del plata',
     'manado',
     'cidreira',
     'forestville',
     'aykhal',
     'warqla',
     'grindavik',
     'toliary',
     'chateaubelair',
     'ankazobe',
     'fortuna',
     'tadine',
     'muroto',
     'lokoja',
     'tefe',
     'marawi',
     'peniche',
     'juneau',
     'ayr',
     'babanusah',
     'zeya',
     'broome',
     'aleksandrov gay',
     'bhadrak',
     'shirokiy',
     'hendersonville',
     'yamada',
     'walvis bay',
     'nangomba',
     'bengkulu',
     'suamico',
     'ngunguru',
     'mugur-aksy',
     'iracoubo',
     'amazar',
     'ostrovnoy',
     'hobyo',
     'erice',
     'rio gallegos',
     'kysyl-syr',
     'yarmouth',
     'maun',
     'kaitangata',
     'faya',
     'mandalgovi',
     'gayeri',
     'vidim',
     'tignere',
     'fairbanks',
     'do rud',
     'xihe',
     'rawson',
     'thaton',
     'bathsheba',
     'mayo',
     'moose factory',
     'shihezi',
     'castro',
     'nikel',
     'sardarshahr',
     'vysokogornyy',
     'college',
     'mookane',
     'lata',
     'sentyabrskiy',
     'augusto correa',
     'korla',
     'hualmay',
     'lohkva',
     'ketchikan',
     'mabaruma',
     'lorengau',
     'azimur',
     'la paz',
     'lodja',
     'mnogovershinnyy',
     'hami',
     'ambilobe',
     'matamoros',
     'barawe',
     'khandagayty',
     'visby',
     'hasaki',
     'port lincoln',
     'joshimath',
     'tabarqah',
     'skalistyy',
     'balkanabat',
     'rungata',
     'togul',
     'vao',
     'pacific grove',
     'luanda',
     'tarudant',
     'tirumullaivasal',
     'asfi',
     'bac lieu',
     'krasnoselkup',
     'attawapiskat',
     'pachino',
     'gobabis',
     'maningrida',
     'ust-nera',
     'tomohon',
     'hammerfest',
     'olinda',
     'xiongshi',
     'amapa',
     'vasto',
     'kerman',
     'darhan',
     'tilichiki',
     'hamilton',
     'dalhousie',
     'banda aceh',
     'tura',
     'pisco',
     'oudtshoorn',
     'tagab',
     'huilong',
     'nagod',
     'burnie',
     'hermiston',
     'faanui',
     'halalo',
     'oranjestad',
     'rabak',
     'marsa matruh',
     'camocim',
     'praia',
     'west bay',
     'san cristobal',
     'katsuura',
     'kathu',
     'say',
     'san antonio',
     'karakose',
     'zelenogorskiy',
     'rio verde de mato grosso',
     'kemijarvi',
     'half moon bay',
     'huainan',
     'antofagasta',
     'villa union',
     'mehamn',
     'vanimo',
     'valparaiso',
     'mount gambier',
     'grand river south east',
     'altamira',
     'barcarena',
     'port-gentil',
     'san vicente de canete',
     'aswan',
     'dicabisagan',
     'vardo',
     'vestmannaeyjar',
     'meulaboh',
     'atasu',
     'ruatoria',
     'ahuimanu',
     'opuwo',
     'briancon',
     'grand-santi',
     'miles city',
     'dongsheng',
     'saint-georges',
     'victoria',
     'stromness',
     'sola',
     'abiy adi',
     'manta',
     'ekhabi',
     'liepaja',
     'shubarshi',
     'torquay',
     'hearst',
     'barra patuca',
     'margate',
     'port hardy',
     'bulungu',
     'skagastrond',
     'apollonia',
     'kropotkin',
     'tyukhtet',
     'ahtopol',
     'chapada dos guimaraes',
     'mitzic',
     'suvorov',
     'brokopondo',
     'eyl',
     'vilaka',
     'broken hill',
     'farafangana',
     'bundaberg',
     'monte alegre',
     'langsa',
     'bogorodskoye',
     'bartoszyce',
     'isangel',
     'chalons-en-champagne',
     'henties bay',
     'panaba',
     'holme',
     'cockburn town',
     'viedma',
     'miramar',
     'romny',
     'santiago',
     'suntar',
     'eydhafushi',
     'itoman',
     'fukue',
     'kieta',
     'general cepeda',
     'mindelo',
     'malwan',
     'irbeyskoye',
     'kudahuvadhoo',
     'sibolga',
     'benguela',
     'meyungs',
     'gaoua',
     'culebra',
     'gigant',
     'belmonte',
     'talnakh',
     'tahta',
     'gardan diwal',
     'vaitupu',
     'mecca',
     'san juan del cesar',
     'quzhou',
     'nova vicosa',
     'novyy yarychiv',
     'lunino',
     'gizo',
     'burns lake',
     'straumen',
     'camacha',
     'saskatoon',
     'kavaratti',
     'klaksvik',
     'necochea',
     'tyrma',
     'ulu tiram',
     'dauriya',
     'ban nahin',
     'kavieng',
     'nynashamn',
     'bhairab bazar',
     'mazamari',
     'port hedland',
     'severo-yeniseyskiy',
     'nichinan',
     'flinders',
     'kismayo',
     'harelbeke',
     'beipiao',
     'kappeln',
     'kununurra',
     'tshane',
     'batemans bay',
     'riyadh',
     'nhulunbuy',
     'sao sebastiao',
     'ambodifototra',
     'boden',
     'melfort',
     'lewisporte',
     'okhotsk',
     'svetlaya',
     'alihe',
     'mahajanga',
     'sao paulo de olivenca',
     'fare',
     'bacalar',
     'shingu',
     'clyde river',
     'shaoyang',
     'onalaska',
     'chaa-khol',
     'apatity',
     'nuuk',
     'ossora',
     'sibu',
     'altay',
     'piracuruca',
     'ponta delgada',
     'yining',
     'lavrentiya',
     'smithers',
     'mancio lima',
     'cururupu',
     'aranos',
     'ozuluama',
     'beaverlodge',
     'vendome',
     'tiznit',
     'ilkal',
     'shahrud',
     'kanniyakumari',
     'formosa do rio preto',
     'fernie',
     'beringovskiy',
     'nuremberg',
     'ceres',
     'bikaner',
     'sechura',
     'great yarmouth',
     'minggang',
     'nikki',
     'xiaoweizhai',
     'badou',
     'deputatskiy',
     'te anau',
     'san rafael del sur',
     'yulara',
     'marystown',
     'waipawa',
     'porbandar',
     'mondlo',
     'ha giang',
     'kemalpasa',
     'saint-augustin',
     'porto novo',
     'estelle',
     'srandakan']



### Perform API Calls
* Perform a weather check on each city using a series of successive API calls.
* Include a print log of each city as it'sbeing processed (with the city number and city name).



```python
# Save config information.
url = "http://api.openweathermap.org/data/2.5/weather?"
units = "imperial"
```


```python
# Build partial query URL OK
query_url = f"{url}appid={api_key}&units={units}&q="
query_url
```




    'http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q='




```python
settings = {"units": "imperial", "appid": api_key}
total_cities = len(cities)
weather_data = []
lat=[]
lon=[]
temp=[]
cit=[]
temp_max=[]
humidity=[]
wind=[]
date=[]
cloudiness=[]
country=[]
count=1

print('Processing Data Retrieval')
print('-----------------------------')


for city in cities:
   print(f"processing Record {count} of Set {total_cities} | " + city )
   try:
       weather_data = [owm.get_current(city, **settings)]
       lat.append(weather_data[0]["coord"]["lat"])
       lon.append(weather_data[0]["coord"]["lon"])
       temp.append(weather_data[0]["main"]["temp"])
       cit.append(weather_data[0]["name"])
       humidity.append(weather_data[0]["main"]["humidity"])
       temp_max.append(weather_data[0]["main"]["temp_max"])
       country.append(weather_data[0]["sys"]["country"])
       cloudiness.append(weather_data[0]["clouds"]["all"])
       date.append(weather_data[0]["dt"])
       wind.append(weather_data[0]["wind"]["speed"])
       print(query_url + city)   
       
    
      # print(f"Processing Record {record} of Set 1 | {city}")
       #pprint(weather_data)
       count=count + 1
   except Exception as e:
               print(f"no data available for city {city},because of {e}")
               #del cities[count-1]
```

    Processing Data Retrieval
    -----------------------------
    processing Record 1 of Set 602 | husavik
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=husavik
    processing Record 2 of Set 602 | arraial do cabo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=arraial do cabo
    processing Record 3 of Set 602 | cavalcante
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cavalcante
    processing Record 4 of Set 602 | punta arenas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=punta arenas
    processing Record 5 of Set 602 | alofi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=alofi
    processing Record 6 of Set 602 | bluff
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bluff
    processing Record 7 of Set 602 | busselton
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=busselton
    processing Record 8 of Set 602 | qaanaaq
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=qaanaaq
    processing Record 9 of Set 602 | rikitea
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=rikitea
    processing Record 10 of Set 602 | mataura
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mataura
    processing Record 11 of Set 602 | udachnyy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=udachnyy
    processing Record 12 of Set 602 | east london
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=east london
    processing Record 13 of Set 602 | albany
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=albany
    processing Record 14 of Set 602 | ushuaia
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ushuaia
    processing Record 15 of Set 602 | magole
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=magole
    processing Record 16 of Set 602 | hermanus
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hermanus
    processing Record 17 of Set 602 | cape town
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cape town
    processing Record 18 of Set 602 | sao joao da barra
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sao joao da barra
    processing Record 19 of Set 602 | hobart
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hobart
    processing Record 20 of Set 602 | tiksi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tiksi
    processing Record 21 of Set 602 | souillac
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=souillac
    processing Record 22 of Set 602 | severo-kurilsk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=severo-kurilsk
    processing Record 23 of Set 602 | butaritari
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=butaritari
    processing Record 24 of Set 602 | jamestown
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=jamestown
    processing Record 25 of Set 602 | chokurdakh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chokurdakh
    processing Record 26 of Set 602 | oltu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=oltu
    processing Record 27 of Set 602 | neiafu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=neiafu
    processing Record 28 of Set 602 | sur
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sur
    processing Record 29 of Set 602 | bethel
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bethel
    processing Record 30 of Set 602 | sabha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sabha
    processing Record 31 of Set 602 | avarua
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=avarua
    processing Record 32 of Set 602 | khatanga
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=khatanga
    processing Record 33 of Set 602 | mahebourg
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mahebourg
    processing Record 34 of Set 602 | muros
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=muros
    processing Record 35 of Set 602 | umzimvubu
    no data available for city umzimvubu,because of HTTP Error 404: Not Found
    processing Record 35 of Set 602 | new norfolk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=new norfolk
    processing Record 36 of Set 602 | sabancuy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sabancuy
    processing Record 37 of Set 602 | puerto ayora
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=puerto ayora
    processing Record 38 of Set 602 | genhe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=genhe
    processing Record 39 of Set 602 | georgetown
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=georgetown
    processing Record 40 of Set 602 | pevek
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pevek
    processing Record 41 of Set 602 | barrow
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=barrow
    processing Record 42 of Set 602 | balaguer
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=balaguer
    processing Record 43 of Set 602 | yinchuan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yinchuan
    processing Record 44 of Set 602 | villamontes
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=villamontes
    processing Record 45 of Set 602 | bulnes
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bulnes
    processing Record 46 of Set 602 | hilo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hilo
    processing Record 47 of Set 602 | kamenskoye
    no data available for city kamenskoye,because of HTTP Error 404: Not Found
    processing Record 47 of Set 602 | saldanha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saldanha
    processing Record 48 of Set 602 | vostok
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vostok
    processing Record 49 of Set 602 | dickinson
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dickinson
    processing Record 50 of Set 602 | babra
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=babra
    processing Record 51 of Set 602 | zhangjiakou
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zhangjiakou
    processing Record 52 of Set 602 | port alfred
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port alfred
    processing Record 53 of Set 602 | najran
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=najran
    processing Record 54 of Set 602 | nikolskoye
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nikolskoye
    processing Record 55 of Set 602 | turukhansk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=turukhansk
    processing Record 56 of Set 602 | sitka
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sitka
    processing Record 57 of Set 602 | saleaula
    no data available for city saleaula,because of HTTP Error 404: Not Found
    processing Record 57 of Set 602 | znamenskoye
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=znamenskoye
    processing Record 58 of Set 602 | asadabad
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=asadabad
    processing Record 59 of Set 602 | bredasdorp
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bredasdorp
    processing Record 60 of Set 602 | sainte-maxime
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sainte-maxime
    processing Record 61 of Set 602 | illoqqortoormiut
    no data available for city illoqqortoormiut,because of HTTP Error 404: Not Found
    processing Record 61 of Set 602 | atuona
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=atuona
    processing Record 62 of Set 602 | vaini
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vaini
    processing Record 63 of Set 602 | zangakatun
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zangakatun
    processing Record 64 of Set 602 | thompson
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=thompson
    processing Record 65 of Set 602 | pichayevo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pichayevo
    processing Record 66 of Set 602 | tuktoyaktuk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tuktoyaktuk
    processing Record 67 of Set 602 | mullaitivu
    no data available for city mullaitivu,because of HTTP Error 404: Not Found
    processing Record 67 of Set 602 | gat
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gat
    processing Record 68 of Set 602 | samarai
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=samarai
    processing Record 69 of Set 602 | vieques
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vieques
    processing Record 70 of Set 602 | guangyuan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=guangyuan
    processing Record 71 of Set 602 | kautokeino
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kautokeino
    processing Record 72 of Set 602 | tyler
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tyler
    processing Record 73 of Set 602 | olivet
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=olivet
    processing Record 74 of Set 602 | chuy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chuy
    processing Record 75 of Set 602 | shiyan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shiyan
    processing Record 76 of Set 602 | sinnamary
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sinnamary
    processing Record 77 of Set 602 | upernavik
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=upernavik
    processing Record 78 of Set 602 | amderma
    no data available for city amderma,because of HTTP Error 404: Not Found
    processing Record 78 of Set 602 | iranshahr
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=iranshahr
    processing Record 79 of Set 602 | launceston
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=launceston
    processing Record 80 of Set 602 | hohhot
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hohhot
    processing Record 81 of Set 602 | doha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=doha
    processing Record 82 of Set 602 | marsh harbour
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=marsh harbour
    processing Record 83 of Set 602 | venado tuerto
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=venado tuerto
    processing Record 84 of Set 602 | baculin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=baculin
    processing Record 85 of Set 602 | kenai
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kenai
    processing Record 86 of Set 602 | carnarvon
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=carnarvon
    processing Record 87 of Set 602 | samusu
    no data available for city samusu,because of HTTP Error 404: Not Found
    processing Record 87 of Set 602 | beira
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=beira
    processing Record 88 of Set 602 | lompoc
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lompoc
    processing Record 89 of Set 602 | lagoa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lagoa
    processing Record 90 of Set 602 | nizhniy baskunchak
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nizhniy baskunchak
    processing Record 91 of Set 602 | kyzyl-suu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kyzyl-suu
    processing Record 92 of Set 602 | berlevag
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=berlevag
    processing Record 93 of Set 602 | ballina
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ballina
    processing Record 94 of Set 602 | barentsburg
    no data available for city barentsburg,because of HTTP Error 404: Not Found
    processing Record 94 of Set 602 | toftir
    no data available for city toftir,because of HTTP Error 404: Not Found
    processing Record 94 of Set 602 | labuhan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=labuhan
    processing Record 95 of Set 602 | kendari
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kendari
    processing Record 96 of Set 602 | boyolangu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=boyolangu
    processing Record 97 of Set 602 | srednekolymsk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=srednekolymsk
    processing Record 98 of Set 602 | constitucion
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=constitucion
    processing Record 99 of Set 602 | yellowknife
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yellowknife
    processing Record 100 of Set 602 | sahrak
    no data available for city sahrak,because of HTTP Error 404: Not Found
    processing Record 100 of Set 602 | paamiut
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=paamiut
    processing Record 101 of Set 602 | berbera
    no data available for city berbera,because of HTTP Error 404: Not Found
    processing Record 101 of Set 602 | norman wells
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=norman wells
    processing Record 102 of Set 602 | ekibastuz
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ekibastuz
    processing Record 103 of Set 602 | saint-joseph
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint-joseph
    processing Record 104 of Set 602 | itarema
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=itarema
    processing Record 105 of Set 602 | nanortalik
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nanortalik
    processing Record 106 of Set 602 | inhambane
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=inhambane
    processing Record 107 of Set 602 | saint george
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint george
    processing Record 108 of Set 602 | tubuala
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tubuala
    processing Record 109 of Set 602 | petauke
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=petauke
    processing Record 110 of Set 602 | belushya guba
    no data available for city belushya guba,because of HTTP Error 404: Not Found
    processing Record 110 of Set 602 | kushima
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kushima
    processing Record 111 of Set 602 | mackay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mackay
    processing Record 112 of Set 602 | acajutla
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=acajutla
    processing Record 113 of Set 602 | tsihombe
    no data available for city tsihombe,because of HTTP Error 404: Not Found
    processing Record 113 of Set 602 | mazagao
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mazagao
    processing Record 114 of Set 602 | tabiauea
    no data available for city tabiauea,because of HTTP Error 404: Not Found
    processing Record 114 of Set 602 | kilindoni
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kilindoni
    processing Record 115 of Set 602 | yumen
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yumen
    processing Record 116 of Set 602 | geraldton
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=geraldton
    processing Record 117 of Set 602 | miri
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=miri
    processing Record 118 of Set 602 | sloboda
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sloboda
    processing Record 119 of Set 602 | redlands
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=redlands
    processing Record 120 of Set 602 | duluth
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=duluth
    processing Record 121 of Set 602 | coahuayana
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=coahuayana
    processing Record 122 of Set 602 | kushiro
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kushiro
    processing Record 123 of Set 602 | luderitz
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=luderitz
    processing Record 124 of Set 602 | saint-philippe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint-philippe
    processing Record 125 of Set 602 | atambua
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=atambua
    processing Record 126 of Set 602 | goderich
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=goderich
    processing Record 127 of Set 602 | ilulissat
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ilulissat
    processing Record 128 of Set 602 | teguise
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=teguise
    processing Record 129 of Set 602 | santa rosa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=santa rosa
    processing Record 130 of Set 602 | karratha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=karratha
    processing Record 131 of Set 602 | portland
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=portland
    processing Record 132 of Set 602 | salalah
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=salalah
    processing Record 133 of Set 602 | ostroda
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ostroda
    processing Record 134 of Set 602 | san felipe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san felipe
    processing Record 135 of Set 602 | klichka
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=klichka
    processing Record 136 of Set 602 | bambous virieux
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bambous virieux
    processing Record 137 of Set 602 | manakara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=manakara
    processing Record 138 of Set 602 | ust-koksa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ust-koksa
    processing Record 139 of Set 602 | santa isabel
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=santa isabel
    processing Record 140 of Set 602 | owando
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=owando
    processing Record 141 of Set 602 | tetouan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tetouan
    processing Record 142 of Set 602 | leningradskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=leningradskiy
    processing Record 143 of Set 602 | taolanaro
    no data available for city taolanaro,because of HTTP Error 404: Not Found
    processing Record 143 of Set 602 | ribeira grande
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ribeira grande
    processing Record 144 of Set 602 | pangnirtung
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pangnirtung
    processing Record 145 of Set 602 | haines junction
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=haines junction
    processing Record 146 of Set 602 | okha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=okha
    processing Record 147 of Set 602 | ancud
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ancud
    processing Record 148 of Set 602 | firminy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=firminy
    processing Record 149 of Set 602 | vila velha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vila velha
    processing Record 150 of Set 602 | zorritos
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zorritos
    processing Record 151 of Set 602 | jalpan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=jalpan
    processing Record 152 of Set 602 | kreuztal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kreuztal
    processing Record 153 of Set 602 | dingle
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dingle
    processing Record 154 of Set 602 | longyearbyen
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=longyearbyen
    processing Record 155 of Set 602 | iqaluit
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=iqaluit
    processing Record 156 of Set 602 | hovd
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hovd
    processing Record 157 of Set 602 | lazaro cardenas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lazaro cardenas
    processing Record 158 of Set 602 | auki
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=auki
    processing Record 159 of Set 602 | coihaique
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=coihaique
    processing Record 160 of Set 602 | mys shmidta
    no data available for city mys shmidta,because of HTTP Error 404: Not Found
    processing Record 160 of Set 602 | kihei
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kihei
    processing Record 161 of Set 602 | adrar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=adrar
    processing Record 162 of Set 602 | keti bandar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=keti bandar
    processing Record 163 of Set 602 | acapulco
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=acapulco
    processing Record 164 of Set 602 | laguilayan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=laguilayan
    processing Record 165 of Set 602 | berberati
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=berberati
    processing Record 166 of Set 602 | port elizabeth
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port elizabeth
    processing Record 167 of Set 602 | namatanai
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=namatanai
    processing Record 168 of Set 602 | vila franca do campo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vila franca do campo
    processing Record 169 of Set 602 | jalu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=jalu
    processing Record 170 of Set 602 | marcona
    no data available for city marcona,because of HTTP Error 404: Not Found
    processing Record 170 of Set 602 | northam
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=northam
    processing Record 171 of Set 602 | mayumba
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mayumba
    processing Record 172 of Set 602 | tasiilaq
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tasiilaq
    processing Record 173 of Set 602 | hindoria
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hindoria
    processing Record 174 of Set 602 | namibe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=namibe
    processing Record 175 of Set 602 | esperance
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=esperance
    processing Record 176 of Set 602 | saint-louis
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint-louis
    processing Record 177 of Set 602 | narsaq
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=narsaq
    processing Record 178 of Set 602 | chipinge
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chipinge
    processing Record 179 of Set 602 | saskylakh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saskylakh
    processing Record 180 of Set 602 | havoysund
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=havoysund
    processing Record 181 of Set 602 | yiyang
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yiyang
    processing Record 182 of Set 602 | playas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=playas
    processing Record 183 of Set 602 | statesboro
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=statesboro
    processing Record 184 of Set 602 | kruisfontein
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kruisfontein
    processing Record 185 of Set 602 | honiara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=honiara
    processing Record 186 of Set 602 | vanino
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vanino
    processing Record 187 of Set 602 | takoradi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=takoradi
    processing Record 188 of Set 602 | lere
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lere
    processing Record 189 of Set 602 | kodiak
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kodiak
    processing Record 190 of Set 602 | dikson
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dikson
    processing Record 191 of Set 602 | vila
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vila
    processing Record 192 of Set 602 | sobolevo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sobolevo
    processing Record 193 of Set 602 | zhigansk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zhigansk
    processing Record 194 of Set 602 | monroe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=monroe
    processing Record 195 of Set 602 | galiwinku
    no data available for city galiwinku,because of HTTP Error 404: Not Found
    processing Record 195 of Set 602 | nishihara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nishihara
    processing Record 196 of Set 602 | puerto leguizamo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=puerto leguizamo
    processing Record 197 of Set 602 | kapaa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kapaa
    processing Record 198 of Set 602 | sosnovo-ozerskoye
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sosnovo-ozerskoye
    processing Record 199 of Set 602 | cabo san lucas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cabo san lucas
    processing Record 200 of Set 602 | swellendam
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=swellendam
    processing Record 201 of Set 602 | turka
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=turka
    processing Record 202 of Set 602 | baykit
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=baykit
    processing Record 203 of Set 602 | provideniya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=provideniya
    processing Record 204 of Set 602 | ipil
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ipil
    processing Record 205 of Set 602 | mbandaka
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mbandaka
    processing Record 206 of Set 602 | ende
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ende
    processing Record 207 of Set 602 | san patricio
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san patricio
    processing Record 208 of Set 602 | ixtapa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ixtapa
    processing Record 209 of Set 602 | agapovka
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=agapovka
    processing Record 210 of Set 602 | lasa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lasa
    processing Record 211 of Set 602 | savannah bight
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=savannah bight
    processing Record 212 of Set 602 | dunedin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dunedin
    processing Record 213 of Set 602 | pietarsaari
    no data available for city pietarsaari,because of HTTP Error 404: Not Found
    processing Record 213 of Set 602 | trinidad
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=trinidad
    processing Record 214 of Set 602 | hithadhoo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hithadhoo
    processing Record 215 of Set 602 | tumannyy
    no data available for city tumannyy,because of HTTP Error 404: Not Found
    processing Record 215 of Set 602 | ylivieska
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ylivieska
    processing Record 216 of Set 602 | mount isa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mount isa
    processing Record 217 of Set 602 | yar-sale
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yar-sale
    processing Record 218 of Set 602 | havelock
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=havelock
    processing Record 219 of Set 602 | tobol
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tobol
    processing Record 220 of Set 602 | monrovia
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=monrovia
    processing Record 221 of Set 602 | caravelas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=caravelas
    processing Record 222 of Set 602 | sao filipe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sao filipe
    processing Record 223 of Set 602 | sungairaya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sungairaya
    processing Record 224 of Set 602 | lebu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lebu
    processing Record 225 of Set 602 | huangpi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=huangpi
    processing Record 226 of Set 602 | kunigal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kunigal
    processing Record 227 of Set 602 | cap malheureux
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cap malheureux
    processing Record 228 of Set 602 | bure
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bure
    processing Record 229 of Set 602 | nizhneyansk
    no data available for city nizhneyansk,because of HTTP Error 404: Not Found
    processing Record 229 of Set 602 | touros
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=touros
    processing Record 230 of Set 602 | lichinga
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lichinga
    processing Record 231 of Set 602 | abakaliki
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=abakaliki
    processing Record 232 of Set 602 | svetlogorsk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=svetlogorsk
    processing Record 233 of Set 602 | toguchin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=toguchin
    processing Record 234 of Set 602 | guerrero negro
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=guerrero negro
    processing Record 235 of Set 602 | tuatapere
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tuatapere
    processing Record 236 of Set 602 | cabra
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cabra
    processing Record 237 of Set 602 | torbay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=torbay
    processing Record 238 of Set 602 | cherskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cherskiy
    processing Record 239 of Set 602 | jalalpur jattan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=jalalpur jattan
    processing Record 240 of Set 602 | ahipara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ahipara
    processing Record 241 of Set 602 | airai
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=airai
    processing Record 242 of Set 602 | chapais
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chapais
    processing Record 243 of Set 602 | vanavara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vanavara
    processing Record 244 of Set 602 | salinas
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=salinas
    processing Record 245 of Set 602 | viligili
    no data available for city viligili,because of HTTP Error 404: Not Found
    processing Record 245 of Set 602 | shitkino
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shitkino
    processing Record 246 of Set 602 | dauphin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dauphin
    processing Record 247 of Set 602 | cayenne
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cayenne
    processing Record 248 of Set 602 | mashhad
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mashhad
    processing Record 249 of Set 602 | lolua
    no data available for city lolua,because of HTTP Error 404: Not Found
    processing Record 249 of Set 602 | ponta do sol
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ponta do sol
    processing Record 250 of Set 602 | kushmurun
    no data available for city kushmurun,because of HTTP Error 404: Not Found
    processing Record 250 of Set 602 | gallup
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gallup
    processing Record 251 of Set 602 | mar del plata
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mar del plata
    processing Record 252 of Set 602 | manado
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=manado
    processing Record 253 of Set 602 | cidreira
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cidreira
    processing Record 254 of Set 602 | forestville
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=forestville
    processing Record 255 of Set 602 | aykhal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=aykhal
    processing Record 256 of Set 602 | warqla
    no data available for city warqla,because of HTTP Error 404: Not Found
    processing Record 256 of Set 602 | grindavik
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=grindavik
    processing Record 257 of Set 602 | toliary
    no data available for city toliary,because of HTTP Error 404: Not Found
    processing Record 257 of Set 602 | chateaubelair
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chateaubelair
    processing Record 258 of Set 602 | ankazobe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ankazobe
    processing Record 259 of Set 602 | fortuna
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=fortuna
    processing Record 260 of Set 602 | tadine
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tadine
    processing Record 261 of Set 602 | muroto
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=muroto
    processing Record 262 of Set 602 | lokoja
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lokoja
    processing Record 263 of Set 602 | tefe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tefe
    processing Record 264 of Set 602 | marawi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=marawi
    processing Record 265 of Set 602 | peniche
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=peniche
    processing Record 266 of Set 602 | juneau
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=juneau
    processing Record 267 of Set 602 | ayr
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ayr
    processing Record 268 of Set 602 | babanusah
    no data available for city babanusah,because of HTTP Error 404: Not Found
    processing Record 268 of Set 602 | zeya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zeya
    processing Record 269 of Set 602 | broome
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=broome
    processing Record 270 of Set 602 | aleksandrov gay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=aleksandrov gay
    processing Record 271 of Set 602 | bhadrak
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bhadrak
    processing Record 272 of Set 602 | shirokiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shirokiy
    processing Record 273 of Set 602 | hendersonville
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hendersonville
    processing Record 274 of Set 602 | yamada
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yamada
    processing Record 275 of Set 602 | walvis bay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=walvis bay
    processing Record 276 of Set 602 | nangomba
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nangomba
    processing Record 277 of Set 602 | bengkulu
    no data available for city bengkulu,because of HTTP Error 404: Not Found
    processing Record 277 of Set 602 | suamico
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=suamico
    processing Record 278 of Set 602 | ngunguru
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ngunguru
    processing Record 279 of Set 602 | mugur-aksy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mugur-aksy
    processing Record 280 of Set 602 | iracoubo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=iracoubo
    processing Record 281 of Set 602 | amazar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=amazar
    processing Record 282 of Set 602 | ostrovnoy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ostrovnoy
    processing Record 283 of Set 602 | hobyo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hobyo
    processing Record 284 of Set 602 | erice
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=erice
    processing Record 285 of Set 602 | rio gallegos
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=rio gallegos
    processing Record 286 of Set 602 | kysyl-syr
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kysyl-syr
    processing Record 287 of Set 602 | yarmouth
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yarmouth
    processing Record 288 of Set 602 | maun
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=maun
    processing Record 289 of Set 602 | kaitangata
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kaitangata
    processing Record 290 of Set 602 | faya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=faya
    processing Record 291 of Set 602 | mandalgovi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mandalgovi
    processing Record 292 of Set 602 | gayeri
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gayeri
    processing Record 293 of Set 602 | vidim
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vidim
    processing Record 294 of Set 602 | tignere
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tignere
    processing Record 295 of Set 602 | fairbanks
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=fairbanks
    processing Record 296 of Set 602 | do rud
    no data available for city do rud,because of HTTP Error 404: Not Found
    processing Record 296 of Set 602 | xihe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=xihe
    processing Record 297 of Set 602 | rawson
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=rawson
    processing Record 298 of Set 602 | thaton
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=thaton
    processing Record 299 of Set 602 | bathsheba
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bathsheba
    processing Record 300 of Set 602 | mayo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mayo
    processing Record 301 of Set 602 | moose factory
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=moose factory
    processing Record 302 of Set 602 | shihezi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shihezi
    processing Record 303 of Set 602 | castro
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=castro
    processing Record 304 of Set 602 | nikel
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nikel
    processing Record 305 of Set 602 | sardarshahr
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sardarshahr
    processing Record 306 of Set 602 | vysokogornyy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vysokogornyy
    processing Record 307 of Set 602 | college
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=college
    processing Record 308 of Set 602 | mookane
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mookane
    processing Record 309 of Set 602 | lata
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lata
    processing Record 310 of Set 602 | sentyabrskiy
    no data available for city sentyabrskiy,because of HTTP Error 404: Not Found
    processing Record 310 of Set 602 | augusto correa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=augusto correa
    processing Record 311 of Set 602 | korla
    no data available for city korla,because of HTTP Error 404: Not Found
    processing Record 311 of Set 602 | hualmay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hualmay
    processing Record 312 of Set 602 | lohkva
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lohkva
    processing Record 313 of Set 602 | ketchikan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ketchikan
    processing Record 314 of Set 602 | mabaruma
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mabaruma
    processing Record 315 of Set 602 | lorengau
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lorengau
    processing Record 316 of Set 602 | azimur
    no data available for city azimur,because of HTTP Error 404: Not Found
    processing Record 316 of Set 602 | la paz
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=la paz
    processing Record 317 of Set 602 | lodja
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lodja
    processing Record 318 of Set 602 | mnogovershinnyy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mnogovershinnyy
    processing Record 319 of Set 602 | hami
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hami
    processing Record 320 of Set 602 | ambilobe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ambilobe
    processing Record 321 of Set 602 | matamoros
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=matamoros
    processing Record 322 of Set 602 | barawe
    no data available for city barawe,because of HTTP Error 404: Not Found
    processing Record 322 of Set 602 | khandagayty
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=khandagayty
    processing Record 323 of Set 602 | visby
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=visby
    processing Record 324 of Set 602 | hasaki
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hasaki
    processing Record 325 of Set 602 | port lincoln
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port lincoln
    processing Record 326 of Set 602 | joshimath
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=joshimath
    processing Record 327 of Set 602 | tabarqah
    no data available for city tabarqah,because of HTTP Error 404: Not Found
    processing Record 327 of Set 602 | skalistyy
    no data available for city skalistyy,because of HTTP Error 404: Not Found
    processing Record 327 of Set 602 | balkanabat
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=balkanabat
    processing Record 328 of Set 602 | rungata
    no data available for city rungata,because of HTTP Error 404: Not Found
    processing Record 328 of Set 602 | togul
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=togul
    processing Record 329 of Set 602 | vao
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vao
    processing Record 330 of Set 602 | pacific grove
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pacific grove
    processing Record 331 of Set 602 | luanda
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=luanda
    processing Record 332 of Set 602 | tarudant
    no data available for city tarudant,because of HTTP Error 404: Not Found
    processing Record 332 of Set 602 | tirumullaivasal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tirumullaivasal
    processing Record 333 of Set 602 | asfi
    no data available for city asfi,because of HTTP Error 404: Not Found
    processing Record 333 of Set 602 | bac lieu
    no data available for city bac lieu,because of HTTP Error 404: Not Found
    processing Record 333 of Set 602 | krasnoselkup
    no data available for city krasnoselkup,because of HTTP Error 404: Not Found
    processing Record 333 of Set 602 | attawapiskat
    no data available for city attawapiskat,because of HTTP Error 404: Not Found
    processing Record 333 of Set 602 | pachino
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pachino
    processing Record 334 of Set 602 | gobabis
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gobabis
    processing Record 335 of Set 602 | maningrida
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=maningrida
    processing Record 336 of Set 602 | ust-nera
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ust-nera
    processing Record 337 of Set 602 | tomohon
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tomohon
    processing Record 338 of Set 602 | hammerfest
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hammerfest
    processing Record 339 of Set 602 | olinda
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=olinda
    processing Record 340 of Set 602 | xiongshi
    no data available for city xiongshi,because of HTTP Error 404: Not Found
    processing Record 340 of Set 602 | amapa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=amapa
    processing Record 341 of Set 602 | vasto
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vasto
    processing Record 342 of Set 602 | kerman
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kerman
    processing Record 343 of Set 602 | darhan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=darhan
    processing Record 344 of Set 602 | tilichiki
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tilichiki
    processing Record 345 of Set 602 | hamilton
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hamilton
    processing Record 346 of Set 602 | dalhousie
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dalhousie
    processing Record 347 of Set 602 | banda aceh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=banda aceh
    processing Record 348 of Set 602 | tura
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tura
    processing Record 349 of Set 602 | pisco
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=pisco
    processing Record 350 of Set 602 | oudtshoorn
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=oudtshoorn
    processing Record 351 of Set 602 | tagab
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tagab
    processing Record 352 of Set 602 | huilong
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=huilong
    processing Record 353 of Set 602 | nagod
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nagod
    processing Record 354 of Set 602 | burnie
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=burnie
    processing Record 355 of Set 602 | hermiston
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hermiston
    processing Record 356 of Set 602 | faanui
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=faanui
    processing Record 357 of Set 602 | halalo
    no data available for city halalo,because of HTTP Error 404: Not Found
    processing Record 357 of Set 602 | oranjestad
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=oranjestad
    processing Record 358 of Set 602 | rabak
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=rabak
    processing Record 359 of Set 602 | marsa matruh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=marsa matruh
    processing Record 360 of Set 602 | camocim
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=camocim
    processing Record 361 of Set 602 | praia
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=praia
    processing Record 362 of Set 602 | west bay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=west bay
    processing Record 363 of Set 602 | san cristobal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san cristobal
    processing Record 364 of Set 602 | katsuura
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=katsuura
    processing Record 365 of Set 602 | kathu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kathu
    processing Record 366 of Set 602 | say
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=say
    processing Record 367 of Set 602 | san antonio
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san antonio
    processing Record 368 of Set 602 | karakose
    no data available for city karakose,because of HTTP Error 404: Not Found
    processing Record 368 of Set 602 | zelenogorskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=zelenogorskiy
    processing Record 369 of Set 602 | rio verde de mato grosso
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=rio verde de mato grosso
    processing Record 370 of Set 602 | kemijarvi
    no data available for city kemijarvi,because of HTTP Error 404: Not Found
    processing Record 370 of Set 602 | half moon bay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=half moon bay
    processing Record 371 of Set 602 | huainan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=huainan
    processing Record 372 of Set 602 | antofagasta
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=antofagasta
    processing Record 373 of Set 602 | villa union
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=villa union
    processing Record 374 of Set 602 | mehamn
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mehamn
    processing Record 375 of Set 602 | vanimo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vanimo
    processing Record 376 of Set 602 | valparaiso
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=valparaiso
    processing Record 377 of Set 602 | mount gambier
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mount gambier
    processing Record 378 of Set 602 | grand river south east
    no data available for city grand river south east,because of HTTP Error 404: Not Found
    processing Record 378 of Set 602 | altamira
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=altamira
    processing Record 379 of Set 602 | barcarena
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=barcarena
    processing Record 380 of Set 602 | port-gentil
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port-gentil
    processing Record 381 of Set 602 | san vicente de canete
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san vicente de canete
    processing Record 382 of Set 602 | aswan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=aswan
    processing Record 383 of Set 602 | dicabisagan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dicabisagan
    processing Record 384 of Set 602 | vardo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vardo
    processing Record 385 of Set 602 | vestmannaeyjar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vestmannaeyjar
    processing Record 386 of Set 602 | meulaboh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=meulaboh
    processing Record 387 of Set 602 | atasu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=atasu
    processing Record 388 of Set 602 | ruatoria
    no data available for city ruatoria,because of HTTP Error 404: Not Found
    processing Record 388 of Set 602 | ahuimanu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ahuimanu
    processing Record 389 of Set 602 | opuwo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=opuwo
    processing Record 390 of Set 602 | briancon
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=briancon
    processing Record 391 of Set 602 | grand-santi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=grand-santi
    processing Record 392 of Set 602 | miles city
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=miles city
    processing Record 393 of Set 602 | dongsheng
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dongsheng
    processing Record 394 of Set 602 | saint-georges
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint-georges
    processing Record 395 of Set 602 | victoria
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=victoria
    processing Record 396 of Set 602 | stromness
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=stromness
    processing Record 397 of Set 602 | sola
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sola
    processing Record 398 of Set 602 | abiy adi
    no data available for city abiy adi,because of HTTP Error 404: Not Found
    processing Record 398 of Set 602 | manta
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=manta
    processing Record 399 of Set 602 | ekhabi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ekhabi
    processing Record 400 of Set 602 | liepaja
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=liepaja
    processing Record 401 of Set 602 | shubarshi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shubarshi
    processing Record 402 of Set 602 | torquay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=torquay
    processing Record 403 of Set 602 | hearst
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=hearst
    processing Record 404 of Set 602 | barra patuca
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=barra patuca
    processing Record 405 of Set 602 | margate
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=margate
    processing Record 406 of Set 602 | port hardy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port hardy
    processing Record 407 of Set 602 | bulungu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bulungu
    processing Record 408 of Set 602 | skagastrond
    no data available for city skagastrond,because of HTTP Error 404: Not Found
    processing Record 408 of Set 602 | apollonia
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=apollonia
    processing Record 409 of Set 602 | kropotkin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kropotkin
    processing Record 410 of Set 602 | tyukhtet
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tyukhtet
    processing Record 411 of Set 602 | ahtopol
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ahtopol
    processing Record 412 of Set 602 | chapada dos guimaraes
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chapada dos guimaraes
    processing Record 413 of Set 602 | mitzic
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mitzic
    processing Record 414 of Set 602 | suvorov
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=suvorov
    processing Record 415 of Set 602 | brokopondo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=brokopondo
    processing Record 416 of Set 602 | eyl
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=eyl
    processing Record 417 of Set 602 | vilaka
    no data available for city vilaka,because of HTTP Error 404: Not Found
    processing Record 417 of Set 602 | broken hill
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=broken hill
    processing Record 418 of Set 602 | farafangana
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=farafangana
    processing Record 419 of Set 602 | bundaberg
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bundaberg
    processing Record 420 of Set 602 | monte alegre
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=monte alegre
    processing Record 421 of Set 602 | langsa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=langsa
    processing Record 422 of Set 602 | bogorodskoye
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bogorodskoye
    processing Record 423 of Set 602 | bartoszyce
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bartoszyce
    processing Record 424 of Set 602 | isangel
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=isangel
    processing Record 425 of Set 602 | chalons-en-champagne
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=chalons-en-champagne
    processing Record 426 of Set 602 | henties bay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=henties bay
    processing Record 427 of Set 602 | panaba
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=panaba
    processing Record 428 of Set 602 | holme
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=holme
    processing Record 429 of Set 602 | cockburn town
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cockburn town
    processing Record 430 of Set 602 | viedma
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=viedma
    processing Record 431 of Set 602 | miramar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=miramar
    processing Record 432 of Set 602 | romny
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=romny
    processing Record 433 of Set 602 | santiago
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=santiago
    processing Record 434 of Set 602 | suntar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=suntar
    processing Record 435 of Set 602 | eydhafushi
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=eydhafushi
    processing Record 436 of Set 602 | itoman
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=itoman
    processing Record 437 of Set 602 | fukue
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=fukue
    processing Record 438 of Set 602 | kieta
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kieta
    processing Record 439 of Set 602 | general cepeda
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=general cepeda
    processing Record 440 of Set 602 | mindelo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mindelo
    processing Record 441 of Set 602 | malwan
    no data available for city malwan,because of HTTP Error 404: Not Found
    processing Record 441 of Set 602 | irbeyskoye
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=irbeyskoye
    processing Record 442 of Set 602 | kudahuvadhoo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kudahuvadhoo
    processing Record 443 of Set 602 | sibolga
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sibolga
    processing Record 444 of Set 602 | benguela
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=benguela
    processing Record 445 of Set 602 | meyungs
    no data available for city meyungs,because of HTTP Error 404: Not Found
    processing Record 445 of Set 602 | gaoua
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gaoua
    processing Record 446 of Set 602 | culebra
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=culebra
    processing Record 447 of Set 602 | gigant
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gigant
    processing Record 448 of Set 602 | belmonte
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=belmonte
    processing Record 449 of Set 602 | talnakh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=talnakh
    processing Record 450 of Set 602 | tahta
    no data available for city tahta,because of HTTP Error 404: Not Found
    processing Record 450 of Set 602 | gardan diwal
    no data available for city gardan diwal,because of HTTP Error 404: Not Found
    processing Record 450 of Set 602 | vaitupu
    no data available for city vaitupu,because of HTTP Error 404: Not Found
    processing Record 450 of Set 602 | mecca
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mecca
    processing Record 451 of Set 602 | san juan del cesar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san juan del cesar
    processing Record 452 of Set 602 | quzhou
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=quzhou
    processing Record 453 of Set 602 | nova vicosa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nova vicosa
    processing Record 454 of Set 602 | novyy yarychiv
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=novyy yarychiv
    processing Record 455 of Set 602 | lunino
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lunino
    processing Record 456 of Set 602 | gizo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=gizo
    processing Record 457 of Set 602 | burns lake
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=burns lake
    processing Record 458 of Set 602 | straumen
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=straumen
    processing Record 459 of Set 602 | camacha
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=camacha
    processing Record 460 of Set 602 | saskatoon
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saskatoon
    processing Record 461 of Set 602 | kavaratti
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kavaratti
    processing Record 462 of Set 602 | klaksvik
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=klaksvik
    processing Record 463 of Set 602 | necochea
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=necochea
    processing Record 464 of Set 602 | tyrma
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tyrma
    processing Record 465 of Set 602 | ulu tiram
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ulu tiram
    processing Record 466 of Set 602 | dauriya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=dauriya
    processing Record 467 of Set 602 | ban nahin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ban nahin
    processing Record 468 of Set 602 | kavieng
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kavieng
    processing Record 469 of Set 602 | nynashamn
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nynashamn
    processing Record 470 of Set 602 | bhairab bazar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bhairab bazar
    processing Record 471 of Set 602 | mazamari
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mazamari
    processing Record 472 of Set 602 | port hedland
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=port hedland
    processing Record 473 of Set 602 | severo-yeniseyskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=severo-yeniseyskiy
    processing Record 474 of Set 602 | nichinan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nichinan
    processing Record 475 of Set 602 | flinders
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=flinders
    processing Record 476 of Set 602 | kismayo
    no data available for city kismayo,because of HTTP Error 404: Not Found
    processing Record 476 of Set 602 | harelbeke
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=harelbeke
    processing Record 477 of Set 602 | beipiao
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=beipiao
    processing Record 478 of Set 602 | kappeln
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kappeln
    processing Record 479 of Set 602 | kununurra
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kununurra
    processing Record 480 of Set 602 | tshane
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tshane
    processing Record 481 of Set 602 | batemans bay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=batemans bay
    processing Record 482 of Set 602 | riyadh
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=riyadh
    processing Record 483 of Set 602 | nhulunbuy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nhulunbuy
    processing Record 484 of Set 602 | sao sebastiao
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sao sebastiao
    processing Record 485 of Set 602 | ambodifototra
    no data available for city ambodifototra,because of HTTP Error 404: Not Found
    processing Record 485 of Set 602 | boden
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=boden
    processing Record 486 of Set 602 | melfort
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=melfort
    processing Record 487 of Set 602 | lewisporte
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lewisporte
    processing Record 488 of Set 602 | okhotsk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=okhotsk
    processing Record 489 of Set 602 | svetlaya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=svetlaya
    processing Record 490 of Set 602 | alihe
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=alihe
    processing Record 491 of Set 602 | mahajanga
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mahajanga
    processing Record 492 of Set 602 | sao paulo de olivenca
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sao paulo de olivenca
    processing Record 493 of Set 602 | fare
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=fare
    processing Record 494 of Set 602 | bacalar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bacalar
    processing Record 495 of Set 602 | shingu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shingu
    processing Record 496 of Set 602 | clyde river
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=clyde river
    processing Record 497 of Set 602 | shaoyang
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shaoyang
    processing Record 498 of Set 602 | onalaska
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=onalaska
    processing Record 499 of Set 602 | chaa-khol
    no data available for city chaa-khol,because of HTTP Error 404: Not Found
    processing Record 499 of Set 602 | apatity
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=apatity
    processing Record 500 of Set 602 | nuuk
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nuuk
    processing Record 501 of Set 602 | ossora
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ossora
    processing Record 502 of Set 602 | sibu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sibu
    processing Record 503 of Set 602 | altay
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=altay
    processing Record 504 of Set 602 | piracuruca
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=piracuruca
    processing Record 505 of Set 602 | ponta delgada
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ponta delgada
    processing Record 506 of Set 602 | yining
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yining
    processing Record 507 of Set 602 | lavrentiya
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=lavrentiya
    processing Record 508 of Set 602 | smithers
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=smithers
    processing Record 509 of Set 602 | mancio lima
    no data available for city mancio lima,because of HTTP Error 404: Not Found
    processing Record 509 of Set 602 | cururupu
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=cururupu
    processing Record 510 of Set 602 | aranos
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=aranos
    processing Record 511 of Set 602 | ozuluama
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ozuluama
    processing Record 512 of Set 602 | beaverlodge
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=beaverlodge
    processing Record 513 of Set 602 | vendome
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=vendome
    processing Record 514 of Set 602 | tiznit
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=tiznit
    processing Record 515 of Set 602 | ilkal
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ilkal
    processing Record 516 of Set 602 | shahrud
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=shahrud
    processing Record 517 of Set 602 | kanniyakumari
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kanniyakumari
    processing Record 518 of Set 602 | formosa do rio preto
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=formosa do rio preto
    processing Record 519 of Set 602 | fernie
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=fernie
    processing Record 520 of Set 602 | beringovskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=beringovskiy
    processing Record 521 of Set 602 | nuremberg
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nuremberg
    processing Record 522 of Set 602 | ceres
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ceres
    processing Record 523 of Set 602 | bikaner
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=bikaner
    processing Record 524 of Set 602 | sechura
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=sechura
    processing Record 525 of Set 602 | great yarmouth
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=great yarmouth
    processing Record 526 of Set 602 | minggang
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=minggang
    processing Record 527 of Set 602 | nikki
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=nikki
    processing Record 528 of Set 602 | xiaoweizhai
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=xiaoweizhai
    processing Record 529 of Set 602 | badou
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=badou
    processing Record 530 of Set 602 | deputatskiy
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=deputatskiy
    processing Record 531 of Set 602 | te anau
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=te anau
    processing Record 532 of Set 602 | san rafael del sur
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=san rafael del sur
    processing Record 533 of Set 602 | yulara
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=yulara
    processing Record 534 of Set 602 | marystown
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=marystown
    processing Record 535 of Set 602 | waipawa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=waipawa
    processing Record 536 of Set 602 | porbandar
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=porbandar
    processing Record 537 of Set 602 | mondlo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=mondlo
    processing Record 538 of Set 602 | ha giang
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=ha giang
    processing Record 539 of Set 602 | kemalpasa
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=kemalpasa
    processing Record 540 of Set 602 | saint-augustin
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=saint-augustin
    processing Record 541 of Set 602 | porto novo
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=porto novo
    processing Record 542 of Set 602 | estelle
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=estelle
    processing Record 543 of Set 602 | srandakan
    http://api.openweathermap.org/data/2.5/weather?appid=9586ef608bbf0838f9b387e9d8d4b1da&units=imperial&q=srandakan
    

### Convert Raw Data to DataFrame
* Export the city data into a .csv.
* Display the DataFrame


```python
# Save as a csv  OK
# Note to avoid any issues later, use encoding="utf-8"
weather_data.to_csv("weatherpy.csv", encoding="utf-8", index=False)
weather_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>Cloudiness</th>
      <th>Country</th>
      <th>Date</th>
      <th>Humidity</th>
      <th>Latitude</th>
      <th>Lng</th>
      <th>Max Temp</th>
      <th>Wind Speed</th>
      <th>Temperature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Husavik</td>
      <td>68</td>
      <td>CA</td>
      <td>1562278090</td>
      <td>25</td>
      <td>50.56</td>
      <td>-96.99</td>
      <td>80.01</td>
      <td>5.01</td>
      <td>79.56</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Arraial do Cabo</td>
      <td>40</td>
      <td>BR</td>
      <td>1562278090</td>
      <td>88</td>
      <td>-22.97</td>
      <td>-42.02</td>
      <td>71.60</td>
      <td>5.82</td>
      <td>70.66</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Cavalcante</td>
      <td>0</td>
      <td>BR</td>
      <td>1562278090</td>
      <td>43</td>
      <td>-13.79</td>
      <td>-47.46</td>
      <td>67.22</td>
      <td>1.48</td>
      <td>67.22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Punta Arenas</td>
      <td>75</td>
      <td>CL</td>
      <td>1562278091</td>
      <td>81</td>
      <td>-53.16</td>
      <td>-70.91</td>
      <td>37.40</td>
      <td>11.41</td>
      <td>36.28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alofi</td>
      <td>75</td>
      <td>NU</td>
      <td>1562278091</td>
      <td>73</td>
      <td>-19.06</td>
      <td>-169.92</td>
      <td>77.00</td>
      <td>18.34</td>
      <td>77.00</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Bluff</td>
      <td>100</td>
      <td>AU</td>
      <td>1562278091</td>
      <td>81</td>
      <td>-23.58</td>
      <td>149.07</td>
      <td>59.79</td>
      <td>25.14</td>
      <td>59.79</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Busselton</td>
      <td>49</td>
      <td>AU</td>
      <td>1562278091</td>
      <td>98</td>
      <td>-33.64</td>
      <td>115.35</td>
      <td>48.00</td>
      <td>27.07</td>
      <td>46.29</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Qaanaaq</td>
      <td>100</td>
      <td>GL</td>
      <td>1562278091</td>
      <td>64</td>
      <td>77.48</td>
      <td>-69.36</td>
      <td>42.44</td>
      <td>3.51</td>
      <td>42.44</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Rikitea</td>
      <td>99</td>
      <td>PF</td>
      <td>1562278092</td>
      <td>67</td>
      <td>-23.12</td>
      <td>-134.97</td>
      <td>66.81</td>
      <td>23.11</td>
      <td>66.81</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Mataura</td>
      <td>59</td>
      <td>NZ</td>
      <td>1562278092</td>
      <td>95</td>
      <td>-46.19</td>
      <td>168.86</td>
      <td>43.00</td>
      <td>3.00</td>
      <td>43.00</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Udachnyy</td>
      <td>75</td>
      <td>RU</td>
      <td>1562278092</td>
      <td>82</td>
      <td>66.42</td>
      <td>112.40</td>
      <td>57.20</td>
      <td>6.71</td>
      <td>57.20</td>
    </tr>
    <tr>
      <th>11</th>
      <td>East London</td>
      <td>0</td>
      <td>ZA</td>
      <td>1562278092</td>
      <td>77</td>
      <td>-33.02</td>
      <td>27.91</td>
      <td>51.17</td>
      <td>3.47</td>
      <td>51.17</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Albany</td>
      <td>1</td>
      <td>US</td>
      <td>1562277891</td>
      <td>45</td>
      <td>42.65</td>
      <td>-73.75</td>
      <td>93.00</td>
      <td>6.93</td>
      <td>86.72</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Ushuaia</td>
      <td>0</td>
      <td>AR</td>
      <td>1562278092</td>
      <td>86</td>
      <td>-54.81</td>
      <td>-68.31</td>
      <td>28.40</td>
      <td>5.14</td>
      <td>28.40</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Magole</td>
      <td>0</td>
      <td>TZ</td>
      <td>1562278093</td>
      <td>77</td>
      <td>-6.37</td>
      <td>37.37</td>
      <td>59.05</td>
      <td>2.08</td>
      <td>59.05</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Hermanus</td>
      <td>100</td>
      <td>ZA</td>
      <td>1562278093</td>
      <td>99</td>
      <td>-34.42</td>
      <td>19.24</td>
      <td>54.00</td>
      <td>3.00</td>
      <td>54.00</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Cape Town</td>
      <td>90</td>
      <td>ZA</td>
      <td>1562278093</td>
      <td>100</td>
      <td>-33.93</td>
      <td>18.42</td>
      <td>57.00</td>
      <td>5.82</td>
      <td>54.77</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Sao Joao da Barra</td>
      <td>40</td>
      <td>BR</td>
      <td>1562278093</td>
      <td>88</td>
      <td>-21.64</td>
      <td>-41.05</td>
      <td>75.20</td>
      <td>16.11</td>
      <td>75.20</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Hobart</td>
      <td>40</td>
      <td>AU</td>
      <td>1562278093</td>
      <td>86</td>
      <td>-42.88</td>
      <td>147.33</td>
      <td>39.99</td>
      <td>8.05</td>
      <td>37.02</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Tiksi</td>
      <td>100</td>
      <td>RU</td>
      <td>1562277878</td>
      <td>89</td>
      <td>71.64</td>
      <td>128.87</td>
      <td>36.75</td>
      <td>5.08</td>
      <td>36.75</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Souillac</td>
      <td>0</td>
      <td>FR</td>
      <td>1562278094</td>
      <td>54</td>
      <td>45.60</td>
      <td>-0.60</td>
      <td>82.99</td>
      <td>6.93</td>
      <td>79.03</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Severo-Kurilsk</td>
      <td>100</td>
      <td>RU</td>
      <td>1562278094</td>
      <td>98</td>
      <td>50.68</td>
      <td>156.12</td>
      <td>42.35</td>
      <td>7.90</td>
      <td>42.35</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Butaritari</td>
      <td>0</td>
      <td>KI</td>
      <td>1562278094</td>
      <td>69</td>
      <td>3.07</td>
      <td>172.79</td>
      <td>84.02</td>
      <td>7.09</td>
      <td>84.02</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Jamestown</td>
      <td>0</td>
      <td>AU</td>
      <td>1562278094</td>
      <td>76</td>
      <td>-33.21</td>
      <td>138.60</td>
      <td>51.33</td>
      <td>15.28</td>
      <td>51.33</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Chokurdakh</td>
      <td>84</td>
      <td>RU</td>
      <td>1562278095</td>
      <td>70</td>
      <td>70.62</td>
      <td>147.90</td>
      <td>49.71</td>
      <td>7.87</td>
      <td>49.71</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Oltu</td>
      <td>0</td>
      <td>TR</td>
      <td>1562278095</td>
      <td>90</td>
      <td>40.55</td>
      <td>42.00</td>
      <td>50.25</td>
      <td>1.79</td>
      <td>50.25</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Neiafu</td>
      <td>40</td>
      <td>TO</td>
      <td>1562277864</td>
      <td>83</td>
      <td>-18.65</td>
      <td>-173.98</td>
      <td>75.20</td>
      <td>6.93</td>
      <td>75.20</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Sur</td>
      <td>0</td>
      <td>OM</td>
      <td>1562278095</td>
      <td>69</td>
      <td>22.57</td>
      <td>59.53</td>
      <td>83.19</td>
      <td>16.33</td>
      <td>83.19</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Bethel</td>
      <td>40</td>
      <td>US</td>
      <td>1562277878</td>
      <td>77</td>
      <td>60.79</td>
      <td>-161.76</td>
      <td>60.80</td>
      <td>9.17</td>
      <td>57.54</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Sabha</td>
      <td>0</td>
      <td>LY</td>
      <td>1562278095</td>
      <td>12</td>
      <td>27.03</td>
      <td>14.43</td>
      <td>90.68</td>
      <td>2.19</td>
      <td>90.68</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>513</th>
      <td>Tiznit</td>
      <td>0</td>
      <td>MA</td>
      <td>1562278194</td>
      <td>86</td>
      <td>29.70</td>
      <td>-9.73</td>
      <td>66.56</td>
      <td>9.98</td>
      <td>66.56</td>
    </tr>
    <tr>
      <th>514</th>
      <td>Ilkal</td>
      <td>99</td>
      <td>IN</td>
      <td>1562278194</td>
      <td>79</td>
      <td>15.96</td>
      <td>76.12</td>
      <td>76.15</td>
      <td>20.42</td>
      <td>76.15</td>
    </tr>
    <tr>
      <th>515</th>
      <td>Shahrud</td>
      <td>0</td>
      <td>IR</td>
      <td>1562278194</td>
      <td>57</td>
      <td>36.42</td>
      <td>54.97</td>
      <td>61.73</td>
      <td>1.52</td>
      <td>61.73</td>
    </tr>
    <tr>
      <th>516</th>
      <td>Kanniyakumari</td>
      <td>100</td>
      <td>IN</td>
      <td>1562278194</td>
      <td>83</td>
      <td>8.08</td>
      <td>77.57</td>
      <td>81.32</td>
      <td>16.75</td>
      <td>81.32</td>
    </tr>
    <tr>
      <th>517</th>
      <td>Formosa do Rio Preto</td>
      <td>0</td>
      <td>BR</td>
      <td>1562278195</td>
      <td>41</td>
      <td>-11.04</td>
      <td>-45.19</td>
      <td>79.84</td>
      <td>4.14</td>
      <td>79.84</td>
    </tr>
    <tr>
      <th>518</th>
      <td>Fernie</td>
      <td>90</td>
      <td>CA</td>
      <td>1562278195</td>
      <td>77</td>
      <td>49.50</td>
      <td>-115.06</td>
      <td>59.00</td>
      <td>8.05</td>
      <td>57.22</td>
    </tr>
    <tr>
      <th>519</th>
      <td>Beringovskiy</td>
      <td>7</td>
      <td>RU</td>
      <td>1562278195</td>
      <td>58</td>
      <td>63.05</td>
      <td>179.32</td>
      <td>61.52</td>
      <td>5.19</td>
      <td>61.52</td>
    </tr>
    <tr>
      <th>520</th>
      <td>Nuremberg</td>
      <td>0</td>
      <td>DE</td>
      <td>1562278188</td>
      <td>67</td>
      <td>49.45</td>
      <td>11.08</td>
      <td>64.40</td>
      <td>1.12</td>
      <td>60.55</td>
    </tr>
    <tr>
      <th>521</th>
      <td>Ceres</td>
      <td>0</td>
      <td>BR</td>
      <td>1562278196</td>
      <td>48</td>
      <td>-15.31</td>
      <td>-49.60</td>
      <td>72.03</td>
      <td>0.69</td>
      <td>72.03</td>
    </tr>
    <tr>
      <th>522</th>
      <td>Bikaner</td>
      <td>0</td>
      <td>IN</td>
      <td>1562278197</td>
      <td>35</td>
      <td>28.02</td>
      <td>73.32</td>
      <td>97.12</td>
      <td>21.92</td>
      <td>97.12</td>
    </tr>
    <tr>
      <th>523</th>
      <td>Sechura</td>
      <td>30</td>
      <td>PE</td>
      <td>1562278197</td>
      <td>91</td>
      <td>-5.56</td>
      <td>-80.82</td>
      <td>63.60</td>
      <td>17.40</td>
      <td>63.60</td>
    </tr>
    <tr>
      <th>524</th>
      <td>Great Yarmouth</td>
      <td>100</td>
      <td>GB</td>
      <td>1562278197</td>
      <td>63</td>
      <td>52.61</td>
      <td>1.73</td>
      <td>64.99</td>
      <td>2.24</td>
      <td>62.69</td>
    </tr>
    <tr>
      <th>525</th>
      <td>Minggang</td>
      <td>0</td>
      <td>CN</td>
      <td>1562278197</td>
      <td>66</td>
      <td>32.45</td>
      <td>114.03</td>
      <td>70.07</td>
      <td>2.98</td>
      <td>70.07</td>
    </tr>
    <tr>
      <th>526</th>
      <td>Nikki</td>
      <td>56</td>
      <td>BJ</td>
      <td>1562278197</td>
      <td>89</td>
      <td>9.94</td>
      <td>3.21</td>
      <td>73.38</td>
      <td>6.35</td>
      <td>73.38</td>
    </tr>
    <tr>
      <th>527</th>
      <td>Xiaoweizhai</td>
      <td>100</td>
      <td>CN</td>
      <td>1562278198</td>
      <td>93</td>
      <td>26.23</td>
      <td>107.51</td>
      <td>66.97</td>
      <td>1.95</td>
      <td>66.97</td>
    </tr>
    <tr>
      <th>528</th>
      <td>Badou</td>
      <td>100</td>
      <td>TG</td>
      <td>1562278198</td>
      <td>97</td>
      <td>7.58</td>
      <td>0.61</td>
      <td>72.32</td>
      <td>2.19</td>
      <td>72.32</td>
    </tr>
    <tr>
      <th>529</th>
      <td>Deputatskiy</td>
      <td>86</td>
      <td>RU</td>
      <td>1562278198</td>
      <td>83</td>
      <td>69.30</td>
      <td>139.90</td>
      <td>44.60</td>
      <td>5.73</td>
      <td>44.60</td>
    </tr>
    <tr>
      <th>530</th>
      <td>Te Anau</td>
      <td>65</td>
      <td>NZ</td>
      <td>1562278198</td>
      <td>79</td>
      <td>-45.41</td>
      <td>167.72</td>
      <td>36.68</td>
      <td>2.33</td>
      <td>36.68</td>
    </tr>
    <tr>
      <th>531</th>
      <td>San Rafael del Sur</td>
      <td>40</td>
      <td>NI</td>
      <td>1562278198</td>
      <td>44</td>
      <td>11.85</td>
      <td>-86.44</td>
      <td>93.20</td>
      <td>20.80</td>
      <td>93.20</td>
    </tr>
    <tr>
      <th>532</th>
      <td>Yulara</td>
      <td>0</td>
      <td>AU</td>
      <td>1562278199</td>
      <td>56</td>
      <td>-25.24</td>
      <td>130.99</td>
      <td>42.80</td>
      <td>5.82</td>
      <td>42.80</td>
    </tr>
    <tr>
      <th>533</th>
      <td>Marystown</td>
      <td>88</td>
      <td>CA</td>
      <td>1562277911</td>
      <td>81</td>
      <td>47.17</td>
      <td>-55.16</td>
      <td>54.87</td>
      <td>11.01</td>
      <td>54.87</td>
    </tr>
    <tr>
      <th>534</th>
      <td>Waipawa</td>
      <td>100</td>
      <td>NZ</td>
      <td>1562278199</td>
      <td>95</td>
      <td>-39.94</td>
      <td>176.59</td>
      <td>43.00</td>
      <td>3.00</td>
      <td>43.00</td>
    </tr>
    <tr>
      <th>535</th>
      <td>Porbandar</td>
      <td>100</td>
      <td>IN</td>
      <td>1562278199</td>
      <td>84</td>
      <td>21.64</td>
      <td>69.61</td>
      <td>82.56</td>
      <td>13.22</td>
      <td>82.56</td>
    </tr>
    <tr>
      <th>536</th>
      <td>Mondlo</td>
      <td>0</td>
      <td>ZA</td>
      <td>1562278199</td>
      <td>24</td>
      <td>-27.96</td>
      <td>30.72</td>
      <td>50.39</td>
      <td>10.20</td>
      <td>50.39</td>
    </tr>
    <tr>
      <th>537</th>
      <td>Ha Giang</td>
      <td>100</td>
      <td>VN</td>
      <td>1562278199</td>
      <td>99</td>
      <td>22.83</td>
      <td>104.99</td>
      <td>67.04</td>
      <td>2.46</td>
      <td>67.04</td>
    </tr>
    <tr>
      <th>538</th>
      <td>Kemalpasa</td>
      <td>0</td>
      <td>TR</td>
      <td>1562278200</td>
      <td>42</td>
      <td>38.43</td>
      <td>27.42</td>
      <td>84.20</td>
      <td>8.05</td>
      <td>80.31</td>
    </tr>
    <tr>
      <th>539</th>
      <td>Saint-Augustin</td>
      <td>75</td>
      <td>CA</td>
      <td>1562278200</td>
      <td>45</td>
      <td>45.63</td>
      <td>-73.98</td>
      <td>93.00</td>
      <td>4.70</td>
      <td>89.92</td>
    </tr>
    <tr>
      <th>540</th>
      <td>Porto Novo</td>
      <td>75</td>
      <td>BR</td>
      <td>1562278200</td>
      <td>93</td>
      <td>-23.68</td>
      <td>-45.44</td>
      <td>62.60</td>
      <td>2.24</td>
      <td>62.60</td>
    </tr>
    <tr>
      <th>541</th>
      <td>Estelle</td>
      <td>0</td>
      <td>FR</td>
      <td>1562278200</td>
      <td>83</td>
      <td>43.97</td>
      <td>3.47</td>
      <td>77.00</td>
      <td>5.82</td>
      <td>77.00</td>
    </tr>
    <tr>
      <th>542</th>
      <td>Srandakan</td>
      <td>24</td>
      <td>ID</td>
      <td>1562278201</td>
      <td>87</td>
      <td>-7.94</td>
      <td>110.25</td>
      <td>76.87</td>
      <td>9.55</td>
      <td>76.87</td>
    </tr>
  </tbody>
</table>
<p>543 rows × 10 columns</p>
</div>



### Plotting the Data
* Use proper labeling of the plots using plot titles (including date of analysis) and axes labels.
* Save the plotted figures as .pngs.

#### Latitude vs. Temperature Plot


```python
 # Build a scatter plot for each data type
plt.scatter(weather_data["Latitude"], weather_data["Max Temp"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Max Temperature", )
plt.ylabel("Max Temp"+"(F)")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("Max Temperature vrs Latitude.png")

# Show plot
plt.show()
```


![png](output_12_0.png)


#### Latitude vs. Humidity Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Humidity"], marker="o")

# Incorporate the other graph properties
plt.title("Humidity (%) vs. Latitude")
plt.ylabel("Humidity" +"(%)")
plt.xlabel("Latitude")
plt.grid(True)

# Set the y-limits of the current axes to 100 Fahrenheit

ylim=(0, 100)

# Save the figure
plt.savefig("Humidity vs Latitude.png")

# Show plot
plt.show()
```


![png](output_14_0.png)


#### Latitude vs. Cloudiness Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Cloudiness"], marker="o")

# Incorporate the other graph properties
plt.title("City Latitude vs. Cloudiness ")
plt.ylabel("Cloudiness")
plt.xlabel("Latitude")
plt.grid(True)

# Set the y-limits of the current axes to 100 Fahrenheit

xlim=(-80,100)
ylim=(0, 100)


# Save the figure
plt.savefig("Cloudiness vs Latitude.png")

# Show plot
plt.show()
```


![png](output_16_0.png)


#### Latitude vs. Wind Speed Plot


```python
plt.scatter(weather_data["Latitude"], weather_data["Wind Speed"], marker="o")

# Incorporate the other graph properties
plt.title("Wind Speed (mph) vs. Latitude")
plt.ylabel("Wind Speed")
plt.xlabel("Latitude")
plt.grid(True)

# Save the figure
plt.savefig("Wind Speed vs Latitude.png")

# Show plot
plt.show()
```


![png](output_18_0.png)



```python

```
